# CROKS Tools

## Já configurado
- Supabase URL + anon no config.js
- schema.sql (você já rodou)

## Vercel — Environment Variables (obrigatório pro /s/ID)
SUPABASE_URL=https://gereylsnxtrdlvphbsda.supabase.co
SUPABASE_SERVICE_ROLE_KEY=sb_secret_mLxg8wPkv1yNSidyArGmbQ_5fHyYXpr

## Depois do deploy
1. Copia a URL do site (https://xxx.vercel.app)
2. Em config.js: SITE_URL: 'https://xxx.vercel.app'
3. Redeploy (ou edita e sobe de novo)
4. Painel → criar conta → salvar script

## Loadstring
loadstring(game:HttpGet("https://xxx.vercel.app/s/ID"))()
