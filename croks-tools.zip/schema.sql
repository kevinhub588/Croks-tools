-- ============================================
-- CROKS TOOLS — rode tudo no SQL Editor
-- Pode ser no MESMO projeto Supabase do hub
-- ============================================

create extension if not exists pgcrypto;

create table if not exists public.tool_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  created_at timestamptz default now()
);

create table if not exists public.tool_scripts (
  id text primary key,
  owner_id uuid references auth.users(id) on delete cascade not null,
  name text not null,
  code text,
  storage_path text,
  encoded boolean default false,
  deny_message text default 'CROKS TOOLS SOURCE? AQUI NÃO!',
  blocked_ips text[] default '{}',
  is_active boolean default true,
  views bigint default 0,
  unique_ips bigint default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- se a tabela já existia sem storage_path:
alter table public.tool_scripts add column if not exists storage_path text;
alter table public.tool_scripts add column if not exists code text;

create table if not exists public.tool_access_logs (
  id bigserial primary key,
  script_id text references public.tool_scripts(id) on delete cascade,
  ip text,
  user_agent text,
  success boolean,
  reason text,
  delivered_preview text,
  created_at timestamptz default now()
);

create table if not exists public.tool_alerts (
  id bigserial primary key,
  owner_id uuid references auth.users(id) on delete cascade,
  script_id text,
  kind text,
  detail text,
  ip text,
  created_at timestamptz default now(),
  read boolean default false
);

alter table public.tool_profiles enable row level security;
alter table public.tool_scripts enable row level security;
alter table public.tool_access_logs enable row level security;
alter table public.tool_alerts enable row level security;

drop policy if exists "profiles own" on public.tool_profiles;
create policy "profiles own" on public.tool_profiles
  for all using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "scripts own" on public.tool_scripts;
create policy "scripts own" on public.tool_scripts
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

drop policy if exists "alerts own" on public.tool_alerts;
create policy "alerts own" on public.tool_alerts
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

drop policy if exists "logs read via owner scripts" on public.tool_access_logs;
create policy "logs read via owner scripts" on public.tool_access_logs
  for select using (
    exists (
      select 1 from public.tool_scripts s
      where s.id = script_id and s.owner_id = auth.uid()
    )
  );

-- Storage: bucket privado para scripts grandes (até 5MB)
insert into storage.buckets (id, name, public, file_size_limit)
values ('tool-scripts', 'tool-scripts', false, 5242880)
on conflict (id) do update set file_size_limit = 5242880;

drop policy if exists "tool scripts upload own" on storage.objects;
create policy "tool scripts upload own" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'tool-scripts' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "tool scripts update own" on storage.objects;
create policy "tool scripts update own" on storage.objects
  for update to authenticated
  using (bucket_id = 'tool-scripts' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "tool scripts read own" on storage.objects;
create policy "tool scripts read own" on storage.objects
  for select to authenticated
  using (bucket_id = 'tool-scripts' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "tool scripts delete own" on storage.objects;
create policy "tool scripts delete own" on storage.objects
  for delete to authenticated
  using (bucket_id = 'tool-scripts' and (storage.foldername(name))[1] = auth.uid()::text);
