function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.style.display = 'block';
  setTimeout(() => { el.style.display = 'none'; }, 2200);
}

async function copyText(text) {
  if (!text) return toast('Nada pra copiar');
  try {
    await navigator.clipboard.writeText(text);
    toast('Copiado!');
  } catch {
    toast('Não copiou');
  }
}

// tabs
document.querySelectorAll('.chip[data-tool]').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.chip[data-tool]').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tool-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tool-' + btn.dataset.tool)?.classList.add('active');
  });
});

// ANÚNCIO
document.getElementById('anGen')?.addEventListener('click', () => {
  const title = document.getElementById('anTitle').value.trim() || 'Novo Script';
  const game = document.getElementById('anGame').value.trim() || 'Roblox';
  const desc = document.getElementById('anDesc').value.trim();
  const link = document.getElementById('anLink').value.trim();
  const tags = [];
  if (document.getElementById('anTested').checked) tags.push('verificado');
  if (document.getElementById('anKeyless').checked) tags.push('keyless');
  else tags.push('key');
  if (document.getElementById('anFree').checked) tags.push('free');

  const lines = [
    `✨ **Novo Script: ${title}**`,
    desc ? `> ${desc}` : null,
    '',
    `🎮 **${game}**`,
    `🏷️ ${tags.map(t => `\`${t}\``).join(' · ')}`,
    link ? `\n🔗 ${link}` : null,
    '',
    '_CROKS SCRIPTS_'
  ].filter(v => v !== null);

  document.getElementById('anOut').value = lines.join('\n');
});
document.getElementById('anCopy')?.addEventListener('click', () => {
  copyText(document.getElementById('anOut').value);
});

// LOADSTRING
document.getElementById('lsGen')?.addEventListener('click', () => {
  const url = document.getElementById('lsUrl').value.trim();
  const code = document.getElementById('lsCode').value.trim();
  let out = '';
  if (url) {
    const clean = url.replace(/^['"]|['"]$/g, '');
    out = `loadstring(game:HttpGet("${clean}"))()`;
  } else if (code) {
    if (/loadstring\s*\(/i.test(code)) out = code.trim();
    else out = code.trim();
  }
  document.getElementById('lsOut').value = out;
});
document.getElementById('lsCopy')?.addEventListener('click', () => {
  copyText(document.getElementById('lsOut').value);
});

// TEXTO
function updateTxStats(text) {
  const chars = text.length;
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  document.getElementById('txStats').textContent = `${chars} caracteres · ${words} palavras`;
}
document.getElementById('txIn')?.addEventListener('input', e => {
  const v = e.target.value;
  document.getElementById('txOut').value = v;
  updateTxStats(v);
});
document.getElementById('txTrim')?.addEventListener('click', () => {
  const v = document.getElementById('txIn').value.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  document.getElementById('txIn').value = v;
  document.getElementById('txOut').value = v;
  updateTxStats(v);
});
document.getElementById('txLower')?.addEventListener('click', () => {
  const v = document.getElementById('txIn').value.toLowerCase();
  document.getElementById('txOut').value = v;
  updateTxStats(v);
});
document.getElementById('txUpper')?.addEventListener('click', () => {
  const v = document.getElementById('txIn').value.toUpperCase();
  document.getElementById('txOut').value = v;
  updateTxStats(v);
});
document.getElementById('txOneLine')?.addEventListener('click', () => {
  const v = document.getElementById('txIn').value.replace(/\s+/g, ' ').trim();
  document.getElementById('txOut').value = v;
  updateTxStats(v);
});
document.getElementById('txCopy')?.addEventListener('click', () => {
  copyText(document.getElementById('txOut').value || document.getElementById('txIn').value);
});

// CÓDIGO
document.getElementById('cdB64e')?.addEventListener('click', () => {
  try {
    const v = btoa(unescape(encodeURIComponent(document.getElementById('cdIn').value)));
    document.getElementById('cdOut').value = v;
  } catch {
    toast('Erro no encode');
  }
});
document.getElementById('cdB64d')?.addEventListener('click', () => {
  try {
    const v = decodeURIComponent(escape(atob(document.getElementById('cdIn').value.trim())));
    document.getElementById('cdOut').value = v;
  } catch {
    toast('Base64 inválido');
  }
});
document.getElementById('cdEmpty')?.addEventListener('click', () => {
  const v = document.getElementById('cdIn').value.split('\n').filter(l => l.trim() !== '').join('\n');
  document.getElementById('cdOut').value = v;
});
document.getElementById('cdDup')?.addEventListener('click', () => {
  const seen = new Set();
  const lines = document.getElementById('cdIn').value.split('\n').filter(l => {
    if (seen.has(l)) return false;
    seen.add(l);
    return true;
  });
  document.getElementById('cdOut').value = lines.join('\n');
});
document.getElementById('cdCopy')?.addEventListener('click', () => {
  copyText(document.getElementById('cdOut').value);
});
