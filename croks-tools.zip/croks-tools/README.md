# CROKS TOOLS

Ferramentas locais no browser:
- Anúncio Discord
- Loadstring
- Texto
- Base64 / limpar código

Deploy: Vercel ou Netlify (static).
