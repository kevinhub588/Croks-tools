window.CROKS_TOOLS = {
  SUPABASE_URL: 'https://gereylsnxtrdlvphbsda.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_2bBs8zySi-YbwNqRt4w6Zg_RMAbewrc',
  // SITE_URL: depois do deploy na Vercel, coloque a URL do site (ex: https://crokstools.vercel.app)
  SITE_URL: ''
};
