/* CROKS Tools — ofuscador Lua multi-pass (cliente). Não é criptografia. */
(function (global) {
  const KW = new Set('and break do else elseif end false for function goto if in local nil not or repeat return then true until while'.split(' '));

  function minify(src) {
    let s = src.replace(/--\[\[[\s\S]*?\]\]/g, '\n');
    s = s.replace(/--[^\n]*/g, '');
    s = s.replace(/[ \t]+/g, ' ');
    s = s.replace(/\n{3,}/g, '\n\n');
    return s.trim();
  }

  function encodeStringExpr(str) {
    const bytes = [];
    for (let i = 0; i < str.length; i++) bytes.push(str.charCodeAt(i));
    return `(function()local _t={${bytes.join(',')}}local _s=""for _i=1,#_t do _s=_s..string.char(_t[_i])end return _s end)()`;
  }

  function transformStrings(code) {
    let out = '', i = 0, n = 0;
    while (i < code.length) {
      const c = code[i];
      if (c === '"' || c === "'") {
        let j = i + 1, raw = '', ok = true;
        while (j < code.length) {
          if (code[j] === '\\') { raw += code[j] + (code[j + 1] || ''); j += 2; continue; }
          if (code[j] === c) break;
          raw += code[j]; j++;
        }
        if (j < code.length && raw.length > 0 && raw.length < 60 && /^[\x20-\x7e]*$/.test(raw) && !raw.includes('\\')) {
          out += encodeStringExpr(raw); n++; i = j + 1; continue;
        }
      }
      out += c; i++;
    }
    return { code: out, count: n };
  }

  function renameLocals(code) {
    const locals = new Set();
    const re = /\blocal\s+([A-Za-z_][A-Za-z0-9_]*)/g;
    let m;
    while ((m = re.exec(code))) {
      const n = m[1];
      if (!KW.has(n) && n.length > 1 && !['self','game','script','workspace','Players','Enums'].includes(n)) locals.add(n);
    }
    const map = new Map();
    let i = 0;
    locals.forEach((n) => map.set(n, '_0x' + (i++).toString(16)));
    map.forEach((to, from) => {
      code = code.replace(new RegExp('\\b' + from + '\\b', 'g'), to);
    });
    return { code, count: map.size };
  }

  function junk(code) {
    const noise = [
      'local _ck=function()end;',
      'if false then print("") end;',
      'do local _x=0 _x=_x+1 end;'
    ];
    return noise[Math.floor(Math.random() * noise.length)] + '\n' + code;
  }

  function wrapVM(code) {
    // entrega em payload base64 + decoder (camada extra, não inviolável)
    const b64 = btoa(unescape(encodeURIComponent(code)));
    return [
      'local __b="' + b64 + '"',
      'local __c="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"',
      'local function __d(data)',
      ' local t={}for i=1,#data do t[i]=data:sub(i,i)end',
      ' local r=""local b=0 local n=0',
      ' for i=1,#data do local c=data:sub(i,i) if c~="=" then',
      '  local v=__c:find(c)-1 b=b*64+v n=n+6',
      '  if n>=8 then n=n-8 local byte=math.floor(b/2^(n))%256 r=r..string.char(byte) end end end return r end',
      'local __s=__d(__b)',
      'local __f=loadstring or load',
      'local __fn,__err=__f(__s)',
      'if not __fn then error(__err) end',
      'return __fn()'
    ].join('\n');
  }

  function obfuscate(source, opts) {
    opts = opts || {};
    const report = { passes: [], warnings: [] };
    let code = minify(source);
    report.passes.push('minify');

    const s = transformStrings(code);
    code = s.code;
    report.passes.push('strings:' + s.count);

    const r = renameLocals(code);
    code = r.code;
    report.passes.push('rename:' + r.count);

    if (opts.junk !== false) {
      code = junk(code);
      report.passes.push('junk');
    }
    if (opts.encode) {
      code = wrapVM(code);
      report.passes.push('encoded-payload');
    }
    report.warnings.push('Ofuscação dificulta leitura; não impede dump por executor avançado.');
    return { code, report };
  }

  function deobfuscate(source) {
    let code = source;
    // unwrap simple char tables partially — best effort
    code = code.replace(/\(function\(\)local _t=\{([0-9,]+)\}local _s=""for _i=1,#_t do _s=_s\.\.string\.char\(_t\[_i\]\)end return _s end\)\(\)/g,
      function (_, nums) {
        try {
          return '"' + nums.split(',').map((n) => String.fromCharCode(Number(n))).join('') + '"';
        } catch (e) { return _; }
      });
    // beautify newlines after end/then
    code = code.replace(/\bend\b/g, 'end\n').replace(/\bthen\b/g, 'then\n');
    return { code, note: 'Desofuscação parcial. Payloads encoded/VM não são totalmente revertidos.' };
  }

  global.CroksObf = { obfuscate, deobfuscate, minify };
})(typeof window !== 'undefined' ? window : global);
