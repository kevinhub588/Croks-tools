const cfg = window.CROKS_TOOLS || {};
const sb = (cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY && window.supabase)
  ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY)
  : null;

const authBox = document.getElementById('authBox');
const app = document.getElementById('app');
const site = (cfg.SITE_URL || location.origin).replace(/\/$/, '');
const MAX_BYTES = 5 * 1024 * 1024; // 5 MB

function uid() {
  const a = new Uint8Array(6); crypto.getRandomValues(a);
  return Array.from(a, b => b.toString(16).padStart(2, '0')).join('');
}

function msg(id, t) {
  const el = document.getElementById(id);
  if (el) el.textContent = t;
}

async function session() {
  if (!sb) return null;
  const { data: { session } } = await sb.auth.getSession();
  return session;
}

async function show() {
  const s = await session();
  if (!s) { authBox.hidden = false; app.hidden = true; return; }
  authBox.hidden = true; app.hidden = false;
  await loadScripts();
  await loadAlerts();
}

document.getElementById('btnLogin').onclick = async () => {
  if (!sb) return msg('authMsg', 'Configure config.js (Supabase)');
  const { error } = await sb.auth.signInWithPassword({
    email: document.getElementById('email').value,
    password: document.getElementById('pass').value
  });
  msg('authMsg', error ? error.message : 'OK');
  if (!error) show();
};

document.getElementById('btnReg').onclick = async () => {
  if (!sb) return msg('authMsg', 'Configure config.js');
  const email = document.getElementById('email').value;
  const password = document.getElementById('pass').value;
  const { data, error } = await sb.auth.signUp({ email, password });
  if (error) return msg('authMsg', error.message);
  if (data.user) {
    await sb.from('tool_profiles').upsert({ id: data.user.id, username: email.split('@')[0] });
  }
  msg('authMsg', 'Conta criada. Entre.');
};

document.getElementById('btnOut').onclick = async () => {
  if (sb) await sb.auth.signOut();
  location.reload();
};

// arquivo → textarea (máx 5MB)
const fileInput = document.getElementById('sfile');
if (fileInput) {
  fileInput.onchange = async () => {
    const f = fileInput.files && fileInput.files[0];
    if (!f) return;
    if (f.size > MAX_BYTES) {
      msg('saveMsg', 'Arquivo maior que 5 MB.');
      fileInput.value = '';
      return;
    }
    const text = await f.text();
    document.getElementById('scode').value = text;
    if (!document.getElementById('sname').value) {
      document.getElementById('sname').value = f.name.replace(/\.(lua|txt)$/i, '');
    }
    msg('saveMsg', 'Arquivo carregado (' + Math.round(f.size / 1024) + ' KB). Clique em Salvar.');
  };
}

document.getElementById('btnSave').onclick = async () => {
  if (!sb) return;
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return;

  let id = document.getElementById('sid').value.trim() || uid();
  const name = document.getElementById('sname').value.trim() || 'script';
  let code = document.getElementById('scode').value || '';
  if (!code) return msg('saveMsg', 'Cole o código ou envie um arquivo.');

  const bytes = new TextEncoder().encode(code).length;
  if (bytes > MAX_BYTES) return msg('saveMsg', 'Código maior que 5 MB.');

  const encoded = document.getElementById('senc').checked;
  if (encoded && window.CroksObf) {
    code = CroksObf.obfuscate(code, { encode: true }).code;
  }

  const deny = document.getElementById('sdeny').value || 'CROKS TOOLS SOURCE? AQUI NÃO!';
  const blocked = document.getElementById('sips').value.split(/\n+/).map(s => s.trim()).filter(Boolean);

  msg('saveMsg', 'Salvando…');

  // Arquivos grandes (> 200KB): Storage; senão coluna code
  let storage_path = null;
  let codeCol = code;
  if (bytes > 200 * 1024) {
    storage_path = user.id + '/' + id + '.lua';
    const blob = new Blob([code], { type: 'text/plain' });
    const up = await sb.storage.from('tool-scripts').upload(storage_path, blob, {
      contentType: 'text/plain',
      upsert: true
    });
    if (up.error) {
      msg('saveMsg', 'Storage: ' + up.error.message + ' — rode o schema.sql (bucket tool-scripts)');
      return;
    }
    codeCol = null; // não duplica no banco
  }

  const row = {
    id,
    owner_id: user.id,
    name,
    code: codeCol,
    storage_path,
    encoded,
    deny_message: deny,
    blocked_ips: blocked,
    is_active: true,
    updated_at: new Date().toISOString()
  };

  const { error } = await sb.from('tool_scripts').upsert(row);
  if (error) return msg('saveMsg', error.message);

  const link = site + '/s/' + id;
  msg('saveMsg', 'Salvo (' + Math.round(bytes / 1024) + ' KB). loadstring(game:HttpGet("' + link + '"))()');
  document.getElementById('sid').value = id;
  loadScripts();
};

async function loadScripts() {
  const { data: { user } } = await sb.auth.getUser();
  const { data } = await sb.from('tool_scripts').select('*').eq('owner_id', user.id).order('updated_at', { ascending: false });
  const box = document.getElementById('list');
  if (!data || !data.length) { box.innerHTML = '<p class="status">Nenhum ainda.</p>'; return; }
  box.innerHTML = data.map(s => {
    const link = site + '/s/' + s.id;
    return `<div style="border-bottom:1px solid #1a1a1a;padding:10px 0">
      <strong>${escapeHtml(s.name)}</strong> <span class="badge">${s.is_active ? 'on' : 'off'}</span>
      <div class="status">👁 ${s.views || 0} views · ${s.storage_path ? 'arquivo/storage' : 'db'}</div>
      <div class="status">ID: ${s.id}</div>
      <div class="status">loadstring(game:HttpGet("${link}"))()</div>
      <div class="row">
        <button class="btn btn-ghost" type="button" data-edit="${s.id}">Editar</button>
        <button class="btn btn-ghost" type="button" data-copy="${link}">Copiar URL</button>
      </div>
    </div>`;
  }).join('');

  box.querySelectorAll('[data-edit]').forEach(btn => {
    btn.onclick = async () => {
      const s = data.find(x => x.id === btn.getAttribute('data-edit'));
      if (!s) return;
      document.getElementById('sid').value = s.id;
      document.getElementById('sname').value = s.name || '';
      document.getElementById('sdeny').value = s.deny_message || '';
      document.getElementById('sips').value = (s.blocked_ips || []).join('\n');
      document.getElementById('senc').checked = !!s.encoded;
      if (s.code) {
        document.getElementById('scode').value = s.code;
      } else if (s.storage_path) {
        const dl = await sb.storage.from('tool-scripts').download(s.storage_path);
        if (dl.data) document.getElementById('scode').value = await dl.data.text();
        else document.getElementById('scode').value = '';
      } else {
        document.getElementById('scode').value = '';
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };
  });
  box.querySelectorAll('[data-copy]').forEach(btn => {
    btn.onclick = () => navigator.clipboard.writeText(btn.getAttribute('data-copy'));
  });
}

async function loadAlerts() {
  const { data: { user } } = await sb.auth.getUser();
  const { data } = await sb.from('tool_alerts').select('*').eq('owner_id', user.id).order('created_at', { ascending: false }).limit(30);
  const box = document.getElementById('alerts');
  if (!data || !data.length) { box.innerHTML = '<p class="status">Sem alertas.</p>'; return; }
  box.innerHTML = data.map(a =>
    `<div class="status">${new Date(a.created_at).toLocaleString('pt-BR')} · <b>${escapeHtml(a.kind)}</b> · ${escapeHtml(a.detail || '')} · IP ${a.ip || '—'} · script ${a.script_id || ''}</div>`
  ).join('');
}

function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

show();
