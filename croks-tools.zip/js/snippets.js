window.CROKS_SNIPPETS = [
  { id: 'lp', name: 'LocalPlayer safe', code: 'local Players=game:GetService("Players")\nlocal lp=Players.LocalPlayer or Players.PlayerAdded:Wait()\n' },
  { id: 'notify', name: 'Notify StarterGui', code: 'game:GetService("StarterGui"):SetCore("SendNotification",{Title="CROKS",Text="ok",Duration=3})\n' },
  { id: 'http', name: 'HttpGet protegido', code: 'local function get(u)\n local ok,res=pcall(function()return game:HttpGet(u)end)\n if not ok then warn(res) return nil end\n return res\nend\n' },
  { id: 'char', name: 'Character / Humanoid', code: 'local char=lp.Character or lp.CharacterAdded:Wait()\nlocal hum=char:WaitForChild("Humanoid")\n' },
  { id: 'anti-nil', name: 'Wait service', code: 'local function svc(n)return game:GetService(n)end\nlocal RS=svc("ReplicatedStorage")\n' }
];
