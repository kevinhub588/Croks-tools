const { createClient } = require('@supabase/supabase-js');

function getIp(req) {
  const xf = req.headers['x-forwarded-for'];
  if (typeof xf === 'string') return xf.split(',')[0].trim();
  return req.headers['x-real-ip'] || 'unknown';
}

function isBrowserLike(ua, headers) {
  const u = (ua || '').toLowerCase();
  if (!u) return true;
  if (u.includes('mozilla') && (u.includes('chrome') || u.includes('safari') || u.includes('firefox') || u.includes('edg'))) {
    const accept = (headers['accept'] || '').toLowerCase();
    if (accept.includes('text/html')) return true;
  }
  if (u.includes('curl') || u.includes('wget') || u.includes('python-requests') || u.includes('scrapy')) return true;
  return false;
}

module.exports = async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');

  if (req.method !== 'GET') {
    res.statusCode = 405;
    return res.end('-- method');
  }

  const id = (req.query.id || '').toString();
  if (!id) {
    res.statusCode = 400;
    return res.end('-- missing id');
  }

  const url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) {
    res.statusCode = 500;
    return res.end('-- server misconfig');
  }

  const sb = createClient(url, key, { auth: { persistSession: false } });
  const ip = getIp(req);
  const ua = req.headers['user-agent'] || '';

  const { data: script } = await sb.from('tool_scripts').select('*').eq('id', id).maybeSingle();
  if (!script || script.is_active === false) {
    res.statusCode = 404;
    return res.end('-- not found');
  }

  const deny = script.deny_message || 'CROKS TOOLS SOURCE? AQUI NÃO!';
  const blocked = script.blocked_ips || [];
  if (blocked.includes(ip)) {
    await log(sb, script, ip, ua, false, 'ip_blocked', deny);
    await alert(sb, script, ip, 'ip_blocked', 'IP bloqueado tentou baixar');
    res.statusCode = 403;
    return res.end('-- ' + deny);
  }

  if (isBrowserLike(ua, req.headers)) {
    await log(sb, script, ip, ua, false, 'browser_or_scrape', deny);
    await alert(sb, script, ip, 'source_attempt', 'Tentativa de abrir no browser/scraper');
    res.statusCode = 403;
    return res.end('-- ' + deny + '\n-- CROKS TOOLS');
  }

  const since = new Date(Date.now() - 60000).toISOString();
  const { count } = await sb.from('tool_access_logs').select('*', { count: 'exact', head: true })
    .eq('script_id', id).eq('ip', ip).gte('created_at', since);
  if ((count || 0) > 40) {
    await alert(sb, script, ip, 'rate_limit', 'Muitas requests');
    res.statusCode = 429;
    return res.end('-- rate');
  }

  let code = script.code || '';
  if (!code && script.storage_path) {
    const dl = await sb.storage.from('tool-scripts').download(script.storage_path);
    if (dl.data) code = await dl.data.text();
  }

  if (!code) {
    res.statusCode = 500;
    return res.end('-- empty');
  }

  await log(sb, script, ip, ua, true, 'ok', code.slice(0, 120));
  await sb.from('tool_scripts').update({ views: (script.views || 0) + 1 }).eq('id', id);

  res.statusCode = 200;
  return res.end(code);
};

async function log(sb, script, ip, ua, success, reason, preview) {
  try {
    await sb.from('tool_access_logs').insert({
      script_id: script.id,
      ip,
      user_agent: String(ua).slice(0, 250),
      success,
      reason,
      delivered_preview: String(preview || '').slice(0, 200)
    });
  } catch (_) {}
}

async function alert(sb, script, ip, kind, detail) {
  try {
    await sb.from('tool_alerts').insert({
      owner_id: script.owner_id,
      script_id: script.id,
      kind,
      detail,
      ip
    });
  } catch (_) {}
}
